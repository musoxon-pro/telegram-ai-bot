
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
from collections import deque
import logging
import os

# 1. Bot token (Railway variables orqali o‘rnatiladi)
TOKEN = os.getenv("TOKEN")

# 2. Log yozuvlarini ko‘rsatish uchun
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

# 3. Chat xotirasi (so‘nggi 50 xabar)
memory = deque(maxlen=50)

# 4. Boshlash komandasi
def start(update, context):
    update.message.reply_text("Salom! Men sizning shaxsiy 'AI'siz AI botingizman. Gaplashamizmi?")

# 5. Javob berish va "aqlli" ko‘rinish berish
def handle_message(update, context):
    text = update.message.text
    user = update.message.from_user.first_name
    memory.append(text)

    lower_text = text.lower()
    if "salom" in lower_text:
        reply = f"Salom, {user}! Qanday yordam bera olaman?"
    elif "yordam" in lower_text or "muammo" in lower_text:
        reply = f"{user}, muammo haqida ko‘proq yozing. Men o‘ylab ko‘raman."
    elif "rahmat" in lower_text:
        reply = "Doim tayyorman!"
    elif any(word in lower_text for word in ["ha", "yo'q", "bilmayman"]):
        reply = f"Tushundim. Yana aytingchi..."
    else:
        reply = f"Qiziq... Shunaqa deyapsiz: '{text}'. Bu haqida o‘ylab ko‘raman."

    if len(memory) > 5:
        reply += f"\n(Yodingizdami, ilgari siz: '{memory[-3]}' deb yozgandingiz...)"

    update.message.reply_text(reply)

# 6. Bot ishga tushirish
def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
